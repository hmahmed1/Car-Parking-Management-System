abstract class Vehicle {
    protected String licensePlate;
    protected String ownerName;

    public Vehicle(String licensePlate, String ownerName) {
        this.licensePlate = licensePlate;
        this.ownerName = ownerName;
    }

    public String getLicensePlate() {
        return licensePlate;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public abstract void park();

    public abstract void remove();
}