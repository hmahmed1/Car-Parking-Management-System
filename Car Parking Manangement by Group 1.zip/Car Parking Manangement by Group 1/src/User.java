import java.io.*;
import java.util.Scanner;
import java.util.Formatter;

public class User {
    private String username;
    private String password;

    public User(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    public boolean login() throws InvalidInputException{
        try (Scanner scanner = new Scanner(new File("F:\\ahmed.txt"))) {
            while (scanner.hasNextLine()) {
                String[] credentials = scanner.nextLine().split(",");
                if (credentials[0].equals(username) && credentials[1].equals(password)) {
                    return true;
                }
            }
            
            throw new InvalidInputException();
        }
        catch (InvalidInputException e){
            System.out.println("username or Password is incorrect ");
        }
        
        
        catch (FileNotFoundException e) {
            System.out.println("error in reading");
        }
        return false;
    }

    public boolean register() {
        try (Formatter out = new Formatter(new FileWriter("F:\\ahmed.txt", true))) {
            out.format("%s,%s%n",username,password);
            return true;
        } catch (IOException e) {
            System.out.println("error in writing");
        }
        return false;
    }
}
