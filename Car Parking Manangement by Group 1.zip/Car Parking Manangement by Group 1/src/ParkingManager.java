import java.util.*;

public class ParkingManager {
    private List<ParkingSlot> parkingSlots;
    private Map<String, ParkingSlot> parkedVehicles;

    public ParkingManager(int numberOfSlots) {
        parkingSlots = new ArrayList<>();
        for (int i = 1; i <= numberOfSlots; i++) {
            parkingSlots.add(new ParkingSlot(i));
        }
        parkedVehicles = new HashMap<>();
    }

public boolean parkVehicle(Vehicle vehicle) {
    for (int i = 0; i < parkingSlots.size(); i++) {
        ParkingSlot slot = parkingSlots.get(i);
        if (!slot.isOccupied()) {
            slot.setParkedVehicle(vehicle);
            slot.park();
            parkedVehicles.put(vehicle.getLicensePlate(), slot);
            return true;
        }
    }
    return false;
}


    public boolean removeVehicle(String licensePlate) {
        if (parkedVehicles.containsKey(licensePlate)) {
            ParkingSlot slot = parkedVehicles.remove(licensePlate);
            slot.remove();
            return true;
        }
        return false;
    }

public void checkParkingStatus() {
    for (int i = 0; i < parkingSlots.size(); i++) {
        ParkingSlot slot = parkingSlots.get(i);
        if (slot.isOccupied()) {
            Vehicle vehicle = slot.getParkedVehicle();
            System.out.println("Slot " + slot.getSlotNumber() + ": Occupied | License Plate: " + vehicle.getLicensePlate() + " | Owner: " + vehicle.getOwnerName());
        } else {
            System.out.println("Slot " + slot.getSlotNumber() + ": Free");
        }
    }
}

}
