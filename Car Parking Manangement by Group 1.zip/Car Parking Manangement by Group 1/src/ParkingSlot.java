public class ParkingSlot implements IParkable {
    private int slotNumber;
    private boolean isOccupied;
    private Vehicle parkedVehicle;

    public ParkingSlot(int slotNumber) {
        this.slotNumber = slotNumber;
        this.isOccupied = false;
    }

    public int getSlotNumber() {
        return slotNumber;
    }

    public boolean isOccupied() {
        return isOccupied;
    }

    public void setOccupied(boolean isOccupied) {
        this.isOccupied = isOccupied;
    }

    public Vehicle getParkedVehicle() {
        return parkedVehicle;
    }

    public void setParkedVehicle(Vehicle parkedVehicle) {
        this.parkedVehicle = parkedVehicle;
    }

    @Override
    public void park() {
        this.isOccupied = true;
        System.out.println("Slot " + slotNumber + " is now occupied.");
    }

    @Override
    public void remove() {
        this.isOccupied = false;
        this.parkedVehicle = null;
        System.out.println("Slot " + slotNumber + " is now free.");
    }
}
