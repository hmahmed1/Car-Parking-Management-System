public interface IParkable {
    void park();
    void remove();
}