public class Car extends Vehicle implements IParkable {
    private String contactNumber;

    public Car(String licensePlate, String ownerName, String contactNumber) {
        super(licensePlate, ownerName);
        this.contactNumber = contactNumber;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    @Override
    public void park() {
        System.out.println("Car parked.");
    }

    @Override
    public void remove() {
        System.out.println("Car removed.");
    }
}